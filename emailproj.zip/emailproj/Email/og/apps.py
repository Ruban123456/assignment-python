from django.apps import AppConfig


class OgConfig(AppConfig):
    name = 'og'
