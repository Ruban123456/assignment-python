
# Register your models here.
from django.contrib import admin
from .models import Registration, Contact

admin.site.register(Registration)
admin.site.register(Contact)
