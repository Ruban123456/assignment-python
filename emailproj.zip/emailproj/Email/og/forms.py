from django import forms
from .models import Registration, Contact


class RegistrationForm(forms.ModelForm):

    class Meta:
        model = Registration
        fields = ['name', 'email']


class ContactForm(forms.ModelForm):

    class Meta:
        model = Contact
        fields = ['name', 'email', 'message']
